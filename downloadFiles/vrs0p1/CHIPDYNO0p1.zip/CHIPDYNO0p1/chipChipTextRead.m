function [geneName, annotation, data] = chipChipTextRead(file1, file2)

% CHIPTEXTREAD reads TXT file for the Lee ChIP data files.
%
% [geneName, annotation, data] = chipChipTextRead(file1, file2)
%

% Copyright (c) 2006 Guido Sanguinetti
% chipChipTextRead.m version 


%CHIPDYNO
[geneName,annotation]=...
    textread(file1,'%q %q %*[^\n]',...
    'headerlines',2,'whitespace','','delimiter','\t');

data = load(file2);