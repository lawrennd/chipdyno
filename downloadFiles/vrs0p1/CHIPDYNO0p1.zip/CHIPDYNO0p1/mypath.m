
addpath('/home/guido/netlab')
addpath('/home/guido/mlprojects/matlab/ndlutil')
addpath('/home/guido/mlprojects/matlab/optimi/matlab')
addpath('/home/guido/mlprojects/kern/matlab')