% CHIPDYNO toolbox
% Version 0.1		Friday 13 Jan 2006 at 15:33
% Copyright (c) 2006 Guido Sanguinetti
% 
